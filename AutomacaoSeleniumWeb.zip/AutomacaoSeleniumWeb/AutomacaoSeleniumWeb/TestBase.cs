﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Chrome;
using System;

namespace AutomacaoSeleniumWeb
{
    public class TestBase
    {
        public ChromeDriver driver;

        [TestInitialize]
        public void MyTestInitialize()
        {
            driver = new ChromeDriver(@"C:\Webdrivers");

            #region Initialize

            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);

            driver.Url = "http://demo.automationtesting.in/index.html";

            #endregion
        }
        [TestCleanup]
        public void MyTestCleanUp()
        {
            driver.Quit();
        }
    }
}
