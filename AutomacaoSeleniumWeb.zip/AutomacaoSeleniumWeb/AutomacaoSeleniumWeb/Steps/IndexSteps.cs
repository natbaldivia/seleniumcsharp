﻿using AutomacaoSeleniumWeb.PageObjects;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Remote;
using System;

namespace AutomacaoSeleniumWeb.Steps
{
    public static class IndexSteps
    {
        public static void ClickSkipSignIn (this RemoteWebDriver driver)
        {
            driver.FindElement(IndexPage.SkipSignIn).Click();
        }

        internal static void ClickSignIn(ChromeDriver driver)
        {
            throw new NotImplementedException();
        }
    }
}
