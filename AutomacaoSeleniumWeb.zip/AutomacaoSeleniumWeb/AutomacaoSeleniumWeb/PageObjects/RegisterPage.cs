﻿using OpenQA.Selenium;

namespace AutomacaoSeleniumWeb.PageObjects
{
    public class RegisterPage
    {
        public static By FirstName = By.XPath("//input[@placeholder='First Name']");
        public static By LastName = By.XPath("//input[@placeholder='Last Name']");
        public static By EmailAddress = By.XPath("//input[@ng-model='EmailAdress']");
        public static By Phone = By.XPath("//input[@ng-model='Phone']");
        public static By GenderMale = By.XPath("//input[@value='Male']");
        public static By GenderFeMale = By.XPath("//input[@value='FeMale']");
        public static By Country = By.XPath("//select[@id='countries']");
        public static By DateOfBirthYear = By.XPath("//select[@id='yearbox']");
        public static By DateOfBirthMonth = By.XPath("//select[@ng-model='monthbox']");
        public static By DateOfBirthDay = By.XPath("//select[@id='daybox']");
        public static By Password = By.XPath("//input[@id='firstpassword']");
        public static By ConfirmPassword = By.XPath("//input[@id='secondpassword']");
        public static By Submit = By.XPath("//button[@id='submitbtn']");
    }
}
