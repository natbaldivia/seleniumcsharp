﻿using AutomacaoSeleniumWeb.Steps;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AutomacaoSeleniumWeb.Features
{
    [TestClass]
        public class RegisterFeature : TestBase
    {


        [TestMethod]
        public void CT01_CadastroComSucesso()
        {
            #region Scenario
            IndexSteps.ClickSkipSignIn(driver);

            Assert.IsTrue(driver.Url.Contains("Register"), "Skip Sign In realizado com sucesso");

            #endregion

            #region Scenario

                RegisterSteps.SetFirstName(driver, "Primeiro");
                RegisterSteps.SetLastName(driver, "Nome");
                RegisterSteps.SetEmailAddress(driver, "natbg.9@gmail.com");
                RegisterSteps.SetPhone(driver, "1199999999");
                RegisterSteps.ClickGenderMale(driver);
                RegisterSteps.SelectCountryByText(driver, "Brazil");
                RegisterSteps.SelectDateOfBirthYearByText(driver, "1991");
                RegisterSteps.SelectDateOfBirthMonthByIndex(driver, 8);
                RegisterSteps.SelectDateOfBirthDayByText(driver, "1");
                RegisterSteps.SetPassword(driver, "Teste@123");
                RegisterSteps.SetConfirmPassword(driver, "Teste@123");
                RegisterSteps.ClickSubmit(driver);

                Assert.IsFalse(WebTableSteps.EditIsEnabled(driver));

            #endregion
        }
            
        }


}   
    

