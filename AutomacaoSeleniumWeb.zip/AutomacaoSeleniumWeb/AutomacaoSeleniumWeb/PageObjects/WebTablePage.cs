﻿using OpenQA.Selenium;

namespace AutomacaoSeleniumWeb.PageObjects
{
    public class WebTablePage
    {
        public static By Edit = By.XPath("//b[text()='EDIT']");
    }
}
