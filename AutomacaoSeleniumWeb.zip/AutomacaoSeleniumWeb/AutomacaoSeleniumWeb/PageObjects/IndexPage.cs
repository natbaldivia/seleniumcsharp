﻿using OpenQA.Selenium;

namespace AutomacaoSeleniumWeb.PageObjects
{
    public class IndexPage
    {
        public static By SkipSignIn = By.Id("btn2");
    }
}
