﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;

namespace AutomacaoSeleniumWeb
{   
    [TestClass]
    public class GoogleTest
    {
        [TestMethod]
        public void TestePesquisar()
        {
            var driver = new ChromeDriver(@"C:\Webdrivers");
            

            try
            {
                driver.Manage().Window.Maximize();
                driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);
                driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);

                driver.Url = "https://www.google.com.br";

                driver.FindElementByXPath("//input[@name='q']").SendKeys("specialty coffee" + Keys.Enter);

                Assert.IsTrue(driver.FindElementByXPath("//a[text()='Notícias']").Enabled);
            }
            catch (Exception e)
            {
                driver.Quit();
                Assert.Fail($"{e.Message}/n{e.InnerException}/n{e.StackTrace}");
            }

            driver.Quit();
        }
    }
}
