﻿using AutomacaoSeleniumWeb.PageObjects;
using OpenQA.Selenium.Remote;

namespace AutomacaoSeleniumWeb.Steps
{
    public class WebTableSteps
    {
        public static bool EditIsEnabled(RemoteWebDriver driver)
        {
            try
            {
                return driver.FindElement(WebTablePage.Edit).Enabled;
            }
            catch
            {
                return false;
            }
        }
    }
}
